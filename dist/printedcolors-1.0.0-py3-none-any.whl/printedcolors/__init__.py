from .colors import Color
from .colours import Colour